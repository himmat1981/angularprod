var express = require('express');
var fs = require('fs');
var app = express();
var multer = require('multer');
var path = require('path');
var bodyParser = require('body-parser');
var mysql = require('mysql');
var mydate = require('current-date');
app.use( bodyParser.json() );       // to support JSON-encoded bodies

app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));



var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "nodejsdb"
});



app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function (request, response) {
  response.render('pages/index');
});

con.connect(function(err) {
    if (err) {
        console.error('Error:- ' + err.stack);
        return;
    }
 
    console.log('Connected Id:- ' + con.threadId);
});



app.use(function(request, response, next) {
  response.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
  response.header('Access-Control-Allow-Origin', '*');
  response.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  response.header('Content-Type', 'application/json');
  next();
});

var storage = multer.diskStorage({
  // destination
  destination: function (req, file, cb) {
    cb(null, './uploads')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});
//var upload = multer({ storage: storage });
var upload = multer({ storage: storage }).array("uploads[]", 12); 


app.get('/uploads/:file', function (req, res){
    file = req.params.file;
    var dirname = path.resolve(".")+'/uploads/';
    var img = fs.readFileSync(dirname  + file);
    res.writeHead(200, {'Content-Type': 'image/jpg' });
    res.end(img, 'binary');
}); 


app.post("/upload", upload, function(req, res) {
	console.log(req.files);var path = require('path');
    res.send(req.files[0].filename);
});

app.get('/deleteCustomer', function (request, response) {
  var qid = request.query.id || "";
  if(qid!="") {
  con.query("delete FROM customers where id='"+qid+"'", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
      console.log("Record deleted!");
  });
  
  }
});

app.post('/checkUser', function (request, response) {
  var email = request.body.email || "";
  var password = request.body.password || "";
  var result =  { "email": "", "password": "" };
  //console.log(request.body);
  con.query("SELECT * FROM user where email='"+email+"' and password='"+password+"'", function (err, result, fields) {
    if (err) throw err;
    //console.log(fields);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
	console.log(result);
  });
});

app.get('/searchRecipe', function (request, response) {
  var qid = request.query.searchkey || "";
  if(qid!="") {
  con.query("SELECT * FROM recipe where recipe_name  like '%" + request.query.searchkey + "%'", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
   
	console.log("got record!");
  });
  } 
  else {
  con.query("SELECT * FROM recipe ", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
   
	console.log("got record!");
  });
  }  
});


app.get('/todayRecipe', function (request, response) {
 
  con.query("SELECT * FROM recipe where recipedate='"+mydate('date')+"'  limit 0,1 ", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
   
	console.log("got record!");
  });
 
});


app.get('/searchtypeRecipe', function (request, response) {
 var qid = request.query.type || "";
 var query_part;
  switch(request.query.type) {
    case 'ingredient':
        query_part = 'Order By  main_ingredient desc';
        break;
    case 'dishtype':
        query_part = 'Order By  dish_type desc';
        break;
	case 'cuisine':
        query_part = 'Order By  cuisine desc';
        break;
}
  con.query("SELECT * FROM recipe " + query_part + " " , function (err, result, fields) {
    if (err) throw err;
    console.log(query_part);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
   
	console.log("got record!");
  });
 
});


app.get('/getcustomers', function (request, response) {
  var qid = request.query.id || "";
  if(qid!="") {
  con.query("SELECT * FROM customers where id='"+qid+"'", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
   
	console.log("got record!");
  });
  
  }
  else {
     con.query("SELECT * FROM customers ",function (err, result, fields) {
            if (err) throw err;
            console.log(result);
            //response.body("I have received the ID: ");
            response.json({
                        data: result
                });
                 //response.send(result);

                console.log("got record!");
          }); 
      
    }
  
  
});

app.post('/writeJson', function (request, response) { 
  var arrayOfObjects = request.body;
  console.log(request.body);
  if(request.body.id=="") {
	  var sql = "INSERT INTO customers (firstname, lastname, languages) VALUES ('"+request.body.firstname+"','"+request.body.lastname+"','"+request.body.languages+"')";
	  con.query(sql, function (err, result) {
		if (err) throw err;
		var sql1 = "Update customers set avtar='"+request.body.imgname1+"' where id='"+result.insertId+"'";
		 con.query(sql1, function (err, result) {
			if (err) throw err;
			console.log("1 record inserted");
		});
	  
	  });
  }
  else {
		var sql = "Update customers set firstname='"+request.body.firstname+"',lastname='"+request.body.lastname+"',languages='"+request.body.languages+"' where id='"+request.body.id+"'";
		con.query(sql, function (err, result) {
		if (err) throw err;
		var sql1 = "Update customers set avtar='"+request.body.imgname1+"' where id='"+request.body.id+"'";
		 con.query(sql1, function (err, result) {
			if (err) throw err;
			console.log("1 record inserted");
		});
	  
		});  
  }
  fs.writeFile('./users.json', JSON.stringify(arrayOfObjects), 'utf-8', function (err) {
    if (err) throw err
    response.json({
      status: true
    });
  }) 
})



app.post('/saveRecipe', function (request, response) { 
  var arrayOfObjects = request.body;
  if(request.body.id=="") {
  var sql = "INSERT INTO recipe (recipe_name, description, cuisine, dish_type, main_ingredient, ingredient, instructions, noofservings, source, recipedate ) VALUES ('"+request.body.recipe_name+"','"+request.body.description+"','"+request.body.cuisine+"','"+request.body.dish_type+"','"+request.body.main_ingredient+"','"+request.body.ingredient+"','"+request.body.instructions+"','"+request.body.noofservings+"','"+request.body.source+"', '"+mydate('date')+"' )";
	  con.query(sql, function (err, result) {
		if (err) throw err;
		var sql1 = "Update recipe set recipeImage='"+request.body.imgname1+"' where id='"+result.insertId+"'";
		 con.query(sql1, function (err, result) {
			if (err) throw err;
			console.log("1 record inserted");
		});
	  
	});
  }
  else {
    var sql = "Update recipe set recipe_name='"+request.body.recipe_name+"',description='"+request.body.description+"',cuisine='"+request.body.cuisine+"',dish_type='"+request.body.dish_type+"',main_ingredient='"+request.body.main_ingredient+"',ingredient='"+request.body.ingredient+"',instructions='"+request.body.instructions+"',noofservings='"+request.body.noofservings+"',source='"+request.body.source+"',recipedate='"+mydate('date')+"' where id='"+request.body.id+"'";
	  con.query(sql, function (err, result) {
		if (err) throw err;
		var sql1 = "Update recipe set recipeImage='"+request.body.imgname1+"' where id='"+request.body.id+"'";
		 con.query(sql1, function (err, result) {
			if (err) throw err;
			console.log("1 record inserted");
		});
	  
	});  
  }
})

app.get('/listRecipe', function (request, response) {
  var qid = request.query.id || "";
  if(qid!="") {
  con.query("SELECT * FROM recipe where id='"+qid+"'", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
   
	console.log("got record!");
  });
  
  }
  else {
     con.query("SELECT * FROM recipe ",function (err, result, fields) {
            if (err) throw err;
            console.log(result);
            //response.body("I have received the ID: ");
            response.json({
                        data: result
                });
                 //response.send(result);

                console.log("got record!");
          }); 
      
    }
  
  
});

app.get('/deleteRecipe', function (request, response) {
  var qid = request.query.id || "";
  if(qid!="") {
  con.query("delete FROM recipe where id='"+qid+"'", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //response.body("I have received the ID: ");
    response.json({
		data: result
	});
	 //response.send(result);
      console.log("Record deleted!");
  });
  
  }
});


app.listen(app.get('port'), function () {
  console.log('Node app is running on port', app.get('port'));
});