// Promise Version
import { Injectable }              from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';



@Injectable()
export class RecipeService {
  private heroesUrl = 'students.json';
  constructor(private http: Http) {

  }
  addRecipe(recipe: any): Promise<any> {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      return this.http.post("http://localhost:5000/saveRecipe", recipe, options).toPromise()
          .then(this.extractData)
          .catch(this.handleErrorPromise);
  }

  loadRecipeList(): Promise<any> {
       return this.http.get("http://localhost:5000/listRecipe").toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
  }
  fetchRecipe(id:any): Promise<any> {
       return this.http.get("http://localhost:5000/listRecipe?id="+id).toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
 }
 searchRecipe(searchkey:any): Promise<any> {
       return this.http.get("http://localhost:5000/searchRecipe?searchkey="+searchkey).toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
 }
 searchtypeRecipe(type:any): Promise<any> {
       return this.http.get("http://localhost:5000/searchtypeRecipe?type="+type).toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
 }
 
 todayRecipe(): Promise<any> {
       return this.http.get("http://localhost:5000/todayRecipe").toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
 }

  /*  load(): Promise<any> {
       return this.http.get("http://localhost:5000/getcustomers").toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
    }

    fetchCustomer(id): Promise<any> {
       return this.http.get("http://localhost:5000/getcustomers?id="+id).toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
    }

    deleteCustomer(id): Promise<any> {
       return this.http.get("http://localhost:5000/deleteCustomer?id="+id).toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
    }
*/
 deleteRecipe(id): Promise<any> {
       return this.http.get("http://localhost:5000/deleteRecipe?id="+id).toPromise()
              .then(this.extractData)
              .catch(this.handleErrorPromise);
    }
    private extractData(res: Response) {
          let body = res.json();
          console.log(body);
          return body.data || {};
      }
      private handleErrorObservable (error: Response | any) {
          console.error(error.message || error);
          return Observable.throw(error.message || error);
      }
      private handleErrorPromise (error: Response | any) {
          console.error(error.message || error);
          return Promise.reject(error.message || error);
      }

}
