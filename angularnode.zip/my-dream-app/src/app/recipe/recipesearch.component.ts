import { Component, Input, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { RecipeService } from './../recipe.service';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-recipe',
  templateUrl: './recipesearch.component.html',
  styleUrls: ['./recipesearch.component.css']
})
export class RecipeSearchComponent implements OnInit {
 
  public getData: Array<any> = [];
  public imagename: any;
  type: string;
  sub: any;
 
  constructor(private route: ActivatedRoute, private _router: Router,  private newService: RecipeService) { 
    
     this.imagename = "default.jpg";
  }
 
  ngOnInit() {
       this.sub = this.route.params.subscribe(params => {
        this.type = params['type']; 
        });
      this.newService.searchtypeRecipe(this.type).then(res => {
        console.log(res);
       this.getData = res;
      
    },
      err => err);
  } 

  findRecipe() {
       this.sub = this.route.params.subscribe(params => {
        this.type = params['type']; 
        });
      this.newService.searchtypeRecipe(this.type).then(res => {
        console.log(res);
       this.getData = res;
    },
      err => err);
  }   
   
}

