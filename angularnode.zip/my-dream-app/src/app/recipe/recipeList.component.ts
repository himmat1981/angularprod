import { Component, Input, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { RecipeService } from './../recipe.service';
import { FormGroup,FormBuilder, FormControl, Validators }  from '@angular/forms';
import {Router} from '@angular/router';
import {AuthenticationService} from './../authentication.service'

@Component({
  selector: 'app-recipeList',
  templateUrl: './recipeList.component.html',
  styleUrls: ['./recipeList.component.css']
})
export class RecipeListComponent implements OnInit {
  public getData: any;
  public formData: any;
  public imagename: any;
  public searchRecipe : any;
  public recipeForm : FormGroup;
  public countries = ["African","American","Caribbean"];
  public dishtypes = ["Appetizer","Beverage","Bread"];
  public mainingradients = ["Beans","Beef","Berries","Cheese","Chicken"];
  filesToUpload: Array<File>;
  constructor(private _router: Router, private loginService: AuthenticationService,private formBuilder: FormBuilder, private newService: RecipeService) {
       this.filesToUpload = [];
      this.imagename = "default.jpg";
   }
   upload() {
        this.makeFileRequest("http://localhost:5000/upload", [], this.filesToUpload).then((result) => {
            console.log(result);
            this.imagename = result;
            this.recipeForm.patchValue({imgname1: result}); 
        }, (error) => {
            console.error(error);
        });
    }

    fileChangeEvent(fileInput: any){
        this.filesToUpload = <Array<File>> fileInput.target.files;
    }

    makeFileRequest(url: string, params: Array<string>, files: Array<File>) {
        return new Promise((resolve, reject) => {
            var formData: any = new FormData();
            var xhr = new XMLHttpRequest();
            for(let i =0; i < files.length; i++){
            formData.append("uploads[]", files[i], files[i].name);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4) {
                        if (xhr.status == 200) {
                            resolve(xhr.response);
                        } else {
                            reject(xhr.response);
                        }
                    }
                }
            }
            xhr.open("POST", url, true);
            xhr.send(formData);
        });
    }
  ngOnInit() {
	 this.recipeForm = this.formBuilder.group({
      id: [''],
      recipe_name: ['', Validators.required],
      description: ['', Validators.required],
      cuisine: ['', Validators.required],
      dish_type: ['', Validators.required],
      main_ingredient: ['', Validators.required],
      ingredient: ['', Validators.required],
      instructions: ['', Validators.required],
      noofservings: ['', Validators.required],
      source: ['', Validators.required],
      imgname1: ['']
    });
	this.loadRecipe();
  }
  loadRecipe() {
      this.newService.loadRecipeList()
      .then(res => {
        this.getData = res;
      },
      err => err);
  }
  onSubmit = function (recipe) { console.log(recipe);
    this.newService.addRecipe(recipe).then(res => {
      this._router.navigate(['recipe-list']);
    },
      err => err);
  }
  editRecipe(id) {
        this.newService.fetchRecipe(id).then(res => {
            this.imagename = res[0].recipeImage;
            this.recipeForm.patchValue({recipe_name: res[0].recipe_name}); 
            this.recipeForm.patchValue({description: res[0].description}); 
            this.recipeForm.patchValue({cuisine: res[0].cuisine}); 
            this.recipeForm.patchValue({id: res[0].id}); 
            this.recipeForm.patchValue({dish_type: res[0].dish_type}); 
            this.recipeForm.patchValue({main_ingredient: res[0].main_ingredient}); 
            this.recipeForm.patchValue({instructions: res[0].instructions}); 
            this.recipeForm.patchValue({ingredient: res[0].ingredient}); 
            this.recipeForm.patchValue({noofservings: res[0].noofservings}); 
            this.recipeForm.patchValue({source: res[0].source}); 
            this.recipeForm.patchValue({imgname1: res[0].recipeImage}); 
           
            
        },
        err => err);
        this.loadRecipe();
    }
    deleteRecipe(id) {
        this.newService.deleteRecipe(id).then(res => {
            console.log(res);
        },
        err => err);
        this.loadRecipe();
    }
    recipesearch(searchkey:string){
        this.newService.searchRecipe(searchkey).then(res => {
           
            this.getData = res;
        },
        err => err);
       
    }
}
