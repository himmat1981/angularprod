import { Component, Input, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { RecipeService } from './../recipe.service';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {AuthenticationService} from './../authentication.service'
@Component({
  selector: 'recipe-view',
  templateUrl: './recipeView.component.html',

})
export class RecipeViewComponent implements OnInit {
 
  public getData: any;
  public imagename: any;
  id: number;
  private sub: any;
  constructor(private route: ActivatedRoute, private _router: Router, private loginService: AuthenticationService, private newService: RecipeService) { 
     this.imagename = "default.jpg";
  }
  ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
        this.id = params['id']; 
        });
       console.log(this.id);
        this.newService.fetchRecipe(this.id).then(res => {
            console.log(res[0]);
           this.getData = res;
        },
        err => err);
  }
}
