export class DishType {
	public dishtype = ["Bread","Cake","Salad","Soups","Stews","Smoothies","Bread","Vegetables"];
}