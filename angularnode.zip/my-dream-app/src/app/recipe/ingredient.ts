export class Ingredients {
	public ingredients = ["Beans","Beef","Berries","Cheese","Chicken"];
}