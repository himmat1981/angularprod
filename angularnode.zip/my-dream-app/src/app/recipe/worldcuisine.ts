export class WorldCuisine {
	public worldcuisine = ["African","American","Caribbean","Asian","Indian","Italian"];
}