import { Component, Input, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { RecipeService } from './../recipe.service';
import { FormGroup,FormBuilder, FormControl, Validators }  from '@angular/forms';
import {Router} from '@angular/router';
import {AuthenticationService} from './../authentication.service'
import {WorldCuisine} from './worldcuisine'
import {DishType} from './dishtype'
import {Ingredients} from './ingredient'
@Component({
  selector: 'app-recipe',
  templateUrl: './recipe.component.html',
  styleUrls: ['./recipe.component.css']
})
export class RecipeComponent implements OnInit {
  public recipeForm: FormGroup;
  public getData: any;
  public imagename: any;
  public countries = new WorldCuisine();
  public dishtypes = new DishType();
  public mainingradients = new Ingredients();
  filesToUpload: Array<File>;
  constructor(private _router: Router, private loginService: AuthenticationService, private newService: RecipeService, private formBuilder: FormBuilder) { 
     this.filesToUpload = [];
     this.imagename = "default.jpg";
  }
  upload() {
        this.makeFileRequest("http://localhost:5000/upload", [], this.filesToUpload).then((result) => {
            console.log(result);
            this.imagename = result;
            this.recipeForm.patchValue({imgname1: result}); 
        }, (error) => {
            console.error(error);
        });
    }

    fileChangeEvent(fileInput: any){
        this.filesToUpload = <Array<File>> fileInput.target.files;
    }

    makeFileRequest(url: string, params: Array<string>, files: Array<File>) {
        return new Promise((resolve, reject) => {
            var formData: any = new FormData();
            var xhr = new XMLHttpRequest();
            for(let i =0; i < files.length; i++){
            formData.append("uploads[]", files[i], files[i].name);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4) {
                        if (xhr.status == 200) {
                            resolve(xhr.response);
                        } else {
                            reject(xhr.response);
                        }
                    }
                }
            }
            xhr.open("POST", url, true);
            xhr.send(formData);
        });
    }
  ngOnInit() {
     
    this.recipeForm = this.formBuilder.group({
      id: [''],
      recipe_name: ['', Validators.required],
      description: ['', Validators.required],
      cuisine: ['', Validators.required],
      dish_type: ['', Validators.required],
      main_ingredient: ['', Validators.required],
      ingredient: ['', Validators.required],
      instructions: ['', Validators.required],
      noofservings: ['', Validators.required],
      source: ['', Validators.required],
      imgname1: ['']
    });
  }
  onSubmit = function (recipe) {
    this.newService.addRecipe(recipe).then(res => {
      this._router.navigate(['recipe']);
    },
      err => err);
    this._router.navigate(['recipe-list']);
  } 
}
