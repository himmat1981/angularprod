import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import { HttpModule, JsonpModule  } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { MyDataService } from './my-data.service';
import { RecipeService } from './recipe.service';
import { RegisterService } from './register/register.service';
import {AuthenticationService} from './authentication.service';
import { CustomerComponent } from './customer/customer.component';
import { RecipeListComponent } from './recipe/recipeList.component';
import {LoginComponent} from './login.component';
import {PrivateComponent} from './private.component';
import {MembersComponent} from './members/members.component';
import { SortPipe } from './app.sort';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { ImageUploadModule } from "angular2-image-upload";
import { RecipeComponent } from './recipe/recipe.component';
import { RecipeSearchComponent } from './recipe/recipesearch.component';
import { FrontComponent } from './front/front.component';
import { RegisterComponent } from './register/register.component';
import { RecipeViewComponent } from './recipe/recipeView.component';

const appRoutes: Routes = [
	{ path: 'recipe-list', 
     component: RecipeListComponent
 },
	{ path: 'cook', component: CustomerComponent },
	{ path: 'home',  component: PrivateComponent },
	{ path: 'login',  component: LoginComponent },
  { path: 'front',  component: FrontComponent },
  { path: 'register',  component: RegisterComponent },
 	{ path: 'recipe',  component: RecipeComponent },
  { path: 'viewrecipe/:id',  component: RecipeViewComponent },
  { path: 'listrecipe/:type',  component: RecipeSearchComponent },
	{ path: '',   redirectTo: 'front', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    SortPipe,
    AppComponent,
    CustomerComponent,
    RecipeListComponent,
    LoginComponent,
    PrivateComponent,
    HeaderComponent,
    FooterComponent,
    RecipeComponent,
	  MembersComponent,
    RecipeViewComponent,
    FrontComponent,
    RecipeSearchComponent,
    RegisterComponent

  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule,
    JsonpModule,
    ImageUploadModule,
    ImageUploadModule.forRoot(),
    RouterModule.forRoot(appRoutes)
    ],
    providers: [MyDataService,AuthenticationService, RecipeService, RegisterService],
    bootstrap: [AppComponent]
})
export class AppModule { }