import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import { Http, Response }          from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
//import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
 

 
@Injectable()
export class AuthenticationService {
  constructor(private _router: Router, private http: Http) {}
  logout() {
    localStorage.removeItem("user");
    this._router.navigate(['login']);
  }
  login(user:any): Promise<any> {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
        return this.http.post("http://localhost:5000/checkUser", user , options).toPromise()
      .then(this.extractLogin)
      .catch(this.handleErrorPromise);
  }
  checkCredentials(){
    if (localStorage.getItem("user") === null){
        this._router.navigate(['login']);
    }
  } 
  private extractLogin(res: Response) {
       return res.json().data || {};
   }
   private handleErrorPromise (error: Response | any) {
       console.error(error.message || error);
       return Promise.reject(error.message || error);
   }	
}