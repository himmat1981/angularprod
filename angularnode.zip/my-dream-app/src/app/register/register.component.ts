import { Component, Input, OnInit, OnChanges, SimpleChange, ElementRef } from '@angular/core';
import { RegisterService } from './register.service';
import { FormGroup,FormBuilder, FormControl, Validators }  from '@angular/forms';
import { Router} from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit  {
  
  public userForm : FormGroup;
  private email: string;
  
  constructor(private registerService: RegisterService, private formBuilder: FormBuilder) {
      
  }
  
 
   ngOnInit() {
     console.log(this.email);
      this.userForm  = this.formBuilder.group({
          id:[''],
          firstname : ['',Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])],
          lastname: ['',Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])],
          email: ['', Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])],
         
      });
     
    }
    
    onSubmit = function(user) {
        
       console.log(user);
       /* this.newService.addPerson(user).then(res => {
            console.log(user);
           //  this.loaddata();
        },
        err => err);*/
        
        
    }
   
}
