import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { RecipeService } from './../recipe.service';
@Component({
  selector: 'front',
  templateUrl: './front.component.html',
  styleUrls: ['./front.component.css']
})
export class FrontComponent implements OnInit {
  public getData: any;
  public featurRecipe: Array<any> = [];
  public searchModel: any;
  public todayRecipeFlag: any;
  public imagename: any;
  public searched:any;
  constructor(private _router: Router, private newService: RecipeService) {
     this.searched = false;

   }
  ngOnInit() {
      this.loadRecipeList();
  }
  goLogin() {
      this._router.navigate(['login']);
  }
  
  SearchRecipe(){console.log(this.searchModel);
    this.newService.searchRecipe(this.searchModel).then(res => {
        console.log(res);
        this.searched = true;
        this.getData = res;
    },
    err => err);
    
 } 
 loadRecipeList() {
      this.newService.todayRecipe().then(res => {
        console.log(res);
      
        this.featurRecipe = res;
    },
    err => err);
    
  } 
}
