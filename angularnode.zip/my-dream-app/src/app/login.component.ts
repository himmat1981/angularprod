import {Component, ElementRef, Input, OnInit, OnChanges, SimpleChange } from '@angular/core';
import {AuthenticationService} from './authentication.service';
import { FormGroup,FormBuilder, FormControl, Validators }  from '@angular/forms';
import {Router} from '@angular/router';

@Component({
    selector: 'login-form',
    providers: [AuthenticationService],
    template: `
    <form class="contact_form" [formGroup]="userForm" (ngSubmit) ="onSubmit(userForm.value)" >
      <div class="col-xs-12"><div class="logincontainer">
              <label class="control-label">Email</label>
              <input class="form-control" type="text"  [formControl]="userForm.controls['email']" placeholder="" name="email" >
              <div class="form-group" class="alert alert-danger" [hidden]="userForm.controls['email'].valid || userForm.controls['email'].untouched">
                   Email is required</div>
              <br>
              <label class="control-label">Password</label>
              <input class="form-control" type="text" formControlName="password" placeholder="password" >
              <br>
              <div class="form-group" class="alert alert-danger" [hidden]="userForm.controls['password'].valid || userForm.controls['password'].untouched">
                   Password is required</div>
              <br>
              <input type="submit" value="submit" [disabled]="!userForm.valid" class="btn btn-default form-submit">
          </div>
      </div>
    </form>
        `
})

export class LoginComponent implements OnInit {
    public userForm : FormGroup;

    constructor(private _router: Router, private _service:AuthenticationService, private formBuilder: FormBuilder) {}
    ngOnInit() {
      //this.loginService   .checkCredentials();
    this.userForm  = this.formBuilder.group({
        email : ['',Validators.required],
        password: ['',Validators.required],

    });

    }
    onSubmit = function(user) {
        this._service.login(user).then(res => {
          console.log(res[0].email);
           localStorage.setItem("user", res[0].email);
           this._router.navigate(['home']);
           return true;
        },
        err => err);
       // this.loaddata();
    }
}
