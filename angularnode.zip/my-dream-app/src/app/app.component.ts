import { Component, Input, OnChanges, SimpleChange } from '@angular/core';
import { FormGroup, FormControl, Validators }  from '@angular/forms';
import { MyDataService } from './my-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  obj = {
	 id: "1",
	 name: "himmat",
  }
  arra = ["African","American","Caribbean"];
  isTrue = true;
  myName = "himmat singh";
  items = ["Angular 4", "Angual 2", "Angular 5"];
  newItem = "";
  pushItem = function() {
	  if(this.newItem != "") {
		  this.items.push(this.newItem);
		  this.newItem = "";
	  }
  }
  removeItem = function(index) {
	 this.items.splice(index, 1);
  }
  cname = "HimmaT";
  day = new Date(1981, 3, 15);
  aaaar = [3,7,8,2,1];



  b = 0;
  o = 0;
  h = 0;

  /* ngOnInit() {
	this.form  = new FormGroup({
	  decimal: new FormControl(""),
	  binary: new FormControl(""),
	  octal: new FormControl(""),
	  hexa: new FormControl(""),
    });
  }
  */
  /*
  decimalChanged = function(oldValue, newValue) {
	  if(newValue != "") {
	 this.form.patchValue({binary: parseInt(newValue, 10).toString(2)});
	  this.form.patchValue({octal: parseInt(newValue, 10).toString(8)});
	   this.form.patchValue({hexa: parseInt(newValue, 10).toString(16).toUpperCase()});
	  }
	 else  {
	 this.form.patchValue({binary: ""});
	  this.form.patchValue({octal: ""});
	   this.form.patchValue({hexa: ""});
	  }
  }

   binaryChanged = function(oldValue, newValue) {
	   this.b = this.b + 1;
	   if(this.b == 1 ) {


	  if(newValue != "") {
	 this.form.patchValue({decimal: parseInt(newValue, 2).toString(10)});

	  }
	 else  {
	 this.form.patchValue({decimal: ""});

	  }
	   this.b = 0;
	  }
  }*/

  //this.newService.fetchData();
}
