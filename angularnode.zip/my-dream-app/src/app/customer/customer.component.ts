import { Component, Input, OnInit, OnChanges, SimpleChange, ElementRef } from '@angular/core';
import { MyDataService } from './../my-data.service';
import {AuthenticationService} from './../authentication.service'
import { RecipeService } from './../recipe.service';
import { FormGroup,FormBuilder, FormControl, Validators }  from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit  {
  public getData: any;
  public getRecipe: any;
  public imagename: any;
  public userForm : FormGroup;
  public errorMessage:any;
  filesToUpload: Array<File>;
  
  constructor(private recipeService: RecipeService, private elem : ElementRef, private _router: Router, private newService:MyDataService, private loginService:AuthenticationService, private formBuilder: FormBuilder) {
       this.filesToUpload = [];
       this.imagename = "default.jpg";
  }
  form;
  private fileCounter = 0;

   upload() {
        this.makeFileRequest("http://localhost:5000/upload", [], this.filesToUpload).then((result) => {
            console.log(result);
            this.imagename = result;
            this.userForm.patchValue({imgname1: result}); 
        }, (error) => {
            console.error(error);
        });
    }

    fileChangeEvent(fileInput: any){
        this.filesToUpload = <Array<File>> fileInput.target.files;
    }

    makeFileRequest(url: string, params: Array<string>, files: Array<File>) {
        return new Promise((resolve, reject) => {
            var formData: any = new FormData();
            var xhr = new XMLHttpRequest();
            for(let i =0; i < files.length; i++){
            formData.append("uploads[]", files[i], files[i].name);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4) {
                        if (xhr.status == 200) {
                            resolve(xhr.response);
                        } else {
                            reject(xhr.response);
                        }
                    }
                }
            }
            xhr.open("POST", url, true);
            xhr.send(formData);
        });
    }
 
  ngOnInit() {
      this.loginService.checkCredentials();
      this.userForm  = this.formBuilder.group({
          id:[''],
          firstname : ['',Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])],
          lastname: ['',Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])],
          languages: [''],
          imgname1: ['']
      });
     this.newService.load()
        .then(res => {
          this.getData = res;
          console.log('ini component');
        },
        err => err);
        this.loadRecipe();
      }
    loadRecipe() {
      this.recipeService.loadRecipeList()
      .then(res => {
        this.getRecipe = res;
      },
      err => err);
  }
    editCustomer(id) {
        this.newService.fetchCustomer(id).then(res => {
            this.loaddata();
            console.log( res[0].avtar);
           // this.userForm.setValue(res[0]);
            this.imagename = res[0].avtar;
            this.userForm.patchValue({firstname: res[0].firstname}); 
            this.userForm.patchValue({lastname: res[0].lastname}); 
            this.userForm.patchValue({languages: res[0].languages}); 
            this.userForm.patchValue({id: res[0].id}); 
            this.userForm.patchValue({imgname1: res[0].avtar}); 
            this._router.navigate(['cook']);
        },
        err => err);
        
    }
    deleteCustomer(id) {
        this.newService.deleteCustomer(id).then(res => {
            console.log(res);
        },
        err => err);
        this.loaddata();
    }
    onSubmit = function(user) {
        this.loaddata();
        this.newService.addPerson(user).then(res => {
             this.loaddata();
        },
        err => err);
        
        
    }
    textValidator(control) {
        if(control.value.length < 3) {
                return {'lastname': true}
        }
    }
    loaddata() {
        this.newService.load()
        .then(res => {
          this.getData = res;
          console.log('ini component');
        },
        err => err);
    }
    logout() {
        this.loginService.logout();
    }
}
